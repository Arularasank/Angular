// student.service.ts

import { Injectable } from '@angular/core';
import { Student } from './student.model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

students: Student[] = [{
    id: 1,
    name: 'Ranjith',
    weight: 120,
    company: 'HCL'
},
{
    id: 2,
    name: 'Rammari',
    weight: 70,
    company: 'HCL'
},
{
    id: 3,
    name: 'Selva',
    weight: 50,
    company: 'HCL'
}];

  constructor() { }
   public getEmpDetails(): any {
     const studentsObservable = new Observable(observer => {
            setTimeout(() => {
                observer.next(this.students);
            }, 1000);
     });

     return studentsObservable;
 }
}