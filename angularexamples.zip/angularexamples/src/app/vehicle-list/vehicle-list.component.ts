import { Component, OnInit } from '@angular/core';
import { VehicleServiceService } from '../vehicle-service.service';

@Component({
  selector: 'app-vehicle-list',
  templateUrl: './vehicle-list.component.html',
  styleUrls: ['./vehicle-list.component.css']
})
export class VehicleListComponent implements OnInit {
   private vehicle:any;
  constructor(private vehicleService: VehicleServiceService) { }

  ngOnInit() {

  	//this.loadVehicle();
  }

  loadVehicle(){
  	this.vehicleService.getVehicles().subscribe(data =>{ this.vehicle = data

  			});
  }

}
