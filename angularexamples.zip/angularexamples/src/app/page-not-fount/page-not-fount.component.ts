import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-page-not-fount',
  template: `
    <p>
      page-not-fount works!
    </p>
  `,
  styles: []
})
export class PageNotFountComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
