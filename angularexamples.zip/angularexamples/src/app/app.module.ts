import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AppRoutingModule, routingComponents} from './app-routing.module';
import { TestComponent } from './test/test.component';
import { VehicleListComponent } from './vehicle-list/vehicle-list.component';
import { HttpClientModule } from '@angular/common/http';




@NgModule({
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],

  declarations: [
    AppComponent,
    routingComponents,
    VehicleListComponent
  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
