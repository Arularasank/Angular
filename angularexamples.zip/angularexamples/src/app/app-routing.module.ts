import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';
import { DepartmentListComponent } from './department-list/department-list.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { PageNotFountComponent } from './page-not-fount/page-not-fount.component';
import { DepartmentDetailComponent } from './department-detail/department-detail.component';
import { DepartmentOverviewComponent } from './department-overview/department-overview.component';
import { DepartmentContactComponent } from './department-contact/department-contact.component';
import { VehicleListComponent } from './vehicle-list/vehicle-list.component';

const routes: Routes = [
    {path : '', redirectTo:'/vehicles', pathMatch:"full"},
    {path : 'departments', component: DepartmentListComponent},
    {path : 'departments/:id', component: DepartmentDetailComponent,
        children:[
                {path: 'overview', component: DepartmentOverviewComponent},
                {path: 'contact', component: DepartmentContactComponent}
            ]    
    },
    {path : 'employees', component: EmployeeListComponent},
    {path : 'vehicles', component: VehicleListComponent},
    {path : '**', component: PageNotFountComponent} 
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule]
})

export class AppRoutingModule{}
export const routingComponents = [
    DepartmentListComponent, EmployeeListComponent, 
    PageNotFountComponent, DepartmentDetailComponent, 
    DepartmentOverviewComponent, DepartmentContactComponent, VehicleListComponent
    ]