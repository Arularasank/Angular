export class Vehicle {
	private vehicleId:number;
	private vehicleRegNo:string;
	private vehicleStatus:boolean;
	private vehicleType:any={};
}
