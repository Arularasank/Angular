
import { Component, OnInit } from '@angular/core';
import { Student } from './student.model';
import { StudentService } from './student.service';
import { of } from 'rxjs';
import { from } from 'rxjs';
import { interval } from 'rxjs';
import { filter, map } from 'rxjs/operators'; 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

    students: Student[] = [];

    constructor(private studentservice: StudentService) {}
    public studentsObservable;
    ngOnInit() {
      //1 Normal obervables
        this.studentsObservable = this.studentservice.getEmpDetails();
        this.studentsObservable.subscribe((studentsData: Student[]) => {
            this.students = studentsData;
        });

    //   //2 Of example
    //   //const myObservable = of(1, 2, 3);

    //  // const numArray = [1,2,3];
    //  // const myObservable = from(numArray);

    //   const myObserver = {
    //     next: x => console.log('Observer got a next value: ' + x),
    //     error: err => console.error('Observer got an error: ' + err),
    //     complete: () => console.log('Observer got a complete notification'),
    //   };
    //   myObservable.subscribe(myObserver);


      //3 interval
      // const secondsCounter = interval(1000);
      // secondsCounter.subscribe(n =>
      //   console.log(`Hi!`)
      // );


      //4 map and filters to return sq of odd nos.
    const squareOdd = of(1, 2, 3, 4, 5) 
      .pipe( 
      filter(n => n % 2 !== 0), 
      map(n => n * n) 
      ); 
      squareOdd.subscribe(x => 
          console.log(x)
      );
    }
    ngOnDestroy(){
      this.studentsObservable.unsubscribe();
    }
}