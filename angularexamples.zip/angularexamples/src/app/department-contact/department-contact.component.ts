import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-department-contact',
  template: `
    <p>
      department-contact works!
    </p>
  `,
  styles: []
})
export class DepartmentContactComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
