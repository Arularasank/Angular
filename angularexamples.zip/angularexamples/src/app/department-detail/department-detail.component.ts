import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from "@angular/router";

@Component({
  selector: 'app-department-detail',
  template: `
    <h3>
      You selected department with ID : {{departmentId}}
    </h3>
    <p>
      <button (click)="showOverview()">overview</button>
      <button (click)="showContact()">contact</button>
    </p>
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class DepartmentDetailComponent implements OnInit {
  public departmentId;
  constructor(private route: ActivatedRoute, private router: Router) { }

  ngOnInit() {
    let id = parseInt(this.route.snapshot.paramMap.get("id"));
    this.departmentId = id;
  }

  showOverview(){
    this.router.navigate(['overview'],{relativeTo:this.route})
  }
  showContact(){
    this.router.navigate(['contact'],{relativeTo:this.route})
  }

}
