export class Student {
    id: Number;
    name: String;
    weight: Number;
    company: String;
}